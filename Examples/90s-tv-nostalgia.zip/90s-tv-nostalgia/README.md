# 90s TV Nostalgia

A Pen created on CodePen.

Original URL: [https://codepen.io/alexandrevacassin/pen/azbGjzz](https://codepen.io/alexandrevacassin/pen/azbGjzz).

Step back into the 90s with this glitchy tribute to the iconic TV intros that defined the era. Featuring beloved classics like Malcolm in the Middle, Batman (1992), The Simpsons, and The X-Files, this project brings to life the vintage charm of old-school TV screens. 