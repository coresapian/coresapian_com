# Horizontal Hieroglyph Matrix

A Pen created on CodePen.

Original URL: [https://codepen.io/antvo/pen/KWLrEz](https://codepen.io/antvo/pen/KWLrEz).

Runes and Hieroglyphs scroll across the page, matrix style. 