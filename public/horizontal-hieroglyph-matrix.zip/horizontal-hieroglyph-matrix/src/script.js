var cnvs = document.getElementById("canvas");
var cntxt = cnvs.getContext("2d");
var chars = ["♃","∂","ζ","♆","≋","𝛙","⟰","☀",
						 "☽","♅","⫷", "𝞝","☳","Σ","Ϡ","Ϛ",
						 "Δ","ځ","گ"];
var font_size = 28;

function resizeCanvas() {
	cnvs.height = window.innerHeight;
	setTimeout(function() {
		cnvs.width = window.innerWidth;
	}, 0);
}
window.onresize = resizeCanvas();
resizeCanvas();
var rows = cnvs.height / font_size;
var drops = [];
for (var x = 0; x < rows; x++) {
	drops[x] = -1;
}
function draw() {
	cntxt.fillStyle = "rgba(0,0,0,0.05)";
	cntxt.fillRect(0, 0, cnvs.width, cnvs.height);
	cntxt.fillStyle = "#FEA605";
	cntxt.font = font_size + "px helvetica";

	for (var i = 0; i < drops.length; i++) {
		var txt = chars[Math.floor(Math.random() * chars.length)];
		cntxt.fillText(txt, drops[i] * font_size, i * font_size);
		if (drops[i] * font_size > cnvs.width && Math.random() > 0.986) {
			drops[i] = -1;
		}
		drops[i]++;
	}
}